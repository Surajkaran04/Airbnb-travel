package com.example.appentus_dummy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
